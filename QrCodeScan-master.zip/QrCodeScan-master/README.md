#### ZXing二维码扫描Demo

* Demo默认界面
  
  ![](http://upload-images.jianshu.io/upload_images/1507362-a8072756b9ab0ef8?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 打开了扫描界面，这个界面后面可以自己根据需求定制修改。

  ![](http://upload-images.jianshu.io/upload_images/1507362-5e989285282c24ca?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 生成二维码

  ![](http://ww1.sinaimg.cn/large/cfeeee4dly1fcl9tglv2xj20bd0g3glt)
	 
